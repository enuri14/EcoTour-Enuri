// src/pages/Login.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function validateEmail(email = "") {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (!validateEmail(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    if (pwd.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    try {
      setBusy(true);
      await new Promise((r) => setTimeout(r, 800));
      if (remember) localStorage.setItem("eco_auth_email", email);
      else localStorage.removeItem("eco_auth_email");
      navigate("/");
    } catch {
      setError("Login failed. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-[calc(100dvh-64px)] flex items-center justify-center bg-gradient-to-b from-emerald-50 to-emerald-100 px-4">
      <div className="w-full max-w-xl">
        {/* Card */}
        <div className="rounded-2xl shadow-2xl border border-emerald-900/10 bg-white/95 backdrop-blur p-6 sm:p-8">
          {/* Brand */}
          <div className="flex items-center justify-center gap-3 mb-4">
            <img
              src="/pics/logo.jpeg"
              alt="EcoVenture Logo"
              className="w-10 h-10 rounded-full ring-2 ring-emerald-500/40 object-contain"
            />
            <h1 className="text-2xl font-extrabold bg-gradient-to-r from-emerald-600 to-emerald-700 bg-clip-text text-transparent">
              EcoVenture
            </h1>
          </div>

          {/* Heading */}
          <h2 className="text-center text-2xl font-bold text-emerald-700">Welcome back</h2>
          <p className="text-center text-sm text-slate-600 mt-1">
            Sign in to continue your adventure.
          </p>

          {/* Error */}
          {error && (
            <div
              className="mt-4 rounded-xl border border-red-300 bg-red-50 text-red-700 px-4 py-2 text-sm text-center"
              role="alert"
            >
              {error}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">
                Email
              </label>
              <div className="relative">
                <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
                  <MailIcon className="w-5 h-5" />
                </span>
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full rounded-xl border border-slate-300 bg-white pl-10 pr-3 py-3 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="password" className="block text-sm font-medium text-slate-700">
                  Password
                </label>
                <Link
                  to="/forgot"
                  className="text-xs font-semibold text-emerald-600 hover:text-emerald-700"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
                  <LockIcon className="w-5 h-5" />
                </span>
                <input
                  id="password"
                  type={showPwd ? "text" : "password"}
                  autoComplete="current-password"
                  value={pwd}
                  onChange={(e) => setPwd(e.target.value)}
                  placeholder="Your password"
                  className="w-full rounded-xl border border-slate-300 bg-white pl-10 pr-12 py-3 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPwd((s) => !s)}
                  aria-label={showPwd ? "Hide password" : "Show password"}
                  className="absolute inset-y-0 right-2 my-auto h-8 px-2 rounded-lg text-sm text-slate-600 hover:text-emerald-600 focus:outline-none"
                >
                  {showPwd ? "Hide" : "Show"}
                </button>
              </div>
            </div>

            {/* Options */}
            <div className="flex items-center justify-between">
              <label className="inline-flex items-center gap-2 text-sm text-slate-700">
                <input
                  type="checkbox"
                  className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                />
                Remember me
              </label>
              <Link
                to="/register"
                className="text-sm font-semibold text-emerald-600 hover:text-emerald-700"
              >
                Create account
              </Link>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-70 text-white font-semibold py-3 transition transform active:scale-[0.99] shadow-lg shadow-emerald-600/20"
            >
              <span className="inline-flex items-center justify-center gap-2">
                {busy && <Spinner className="w-4 h-4" />}
                {busy ? "Signing in…" : "Sign in"}
              </span>
            </button>

            {/* Divider */}
            <div className="relative my-1 text-center">
              <span className="px-3 text-xs uppercase tracking-wider text-slate-500">or</span>
            </div>

            {/* Socials */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50 transition"
              >
                <GoogleIcon className="w-5 h-5" />
                Google
              </button>
              <button
                type="button"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 hover:bg-slate-50 transition"
              >
                <GitHubIcon className="w-5 h-5" />
                GitHub
              </button>
            </div>
          </form>

          {/* Terms */}
          <p className="text-center text-xs mt-4 text-slate-600">
            By continuing, you agree to our{" "}
            <Link to="/terms" className="font-semibold text-emerald-600 hover:text-emerald-700">
              Terms
            </Link>{" "}
            &{" "}
            <Link to="/privacy" className="font-semibold text-emerald-600 hover:text-emerald-700">
              Privacy
            </Link>
            .
          </p>
        </div>
      </div>
    </main>
  );
}

/* ---------- Small inline icons ---------- */
function MailIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden>
      <rect x="3" y="5" width="18" height="14" rx="2" strokeWidth="1.8" />
      <path d="M3 7l9 6 9-6" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function LockIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden>
      <rect x="5" y="10" width="14" height="10" rx="2" strokeWidth="1.8" />
      <path d="M8 10V7a4 4 0 118 0v3" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
function Spinner({ className = "" }) {
  return (
    <svg className={`animate-spin ${className}`} viewBox="0 0 24 24" aria-hidden>
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
      <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
    </svg>
  );
}
function GoogleIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden>
      <path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.3-1.7 3.8-5.5 3.8-3.3 0-6-2.7-6-6s2.7-6 6-6c1.9 0 3.2.8 3.9 1.6l2.7-2.7C16.8 3 14.6 2 12 2 6.9 2 2.8 6.1 2.8 11.2S6.9 20.4 12 20.4c7.1 0 9.3-4.9 9.3-7.3 0-.5-.1-1-.2-1.4H12z"/>
      <path fill="#34A853" d="M3.7 7.5l3.2 2.3C7.6 8.2 9.6 6.8 12 6.8c1.9 0 3.2.8 3.9 1.6l2.7-2.7C16.8 3 14.6 2 12 2 8 2 4.7 4.3 3.7 7.5z"/>
      <path fill="#4A90E2" d="M12 20.4c2.6 0 4.8-.9 6.4-2.3l-3-2.5c-.8.6-1.9 1-3.4 1-3.8 0-5.3-2.5-5.5-3.8H1.1c-.1.4-.2.9-.2 1.4 0 3.1 2.7 6.2 6.1 6.2z"/>
      <path fill="#FBBC05" d="M20.5 13.1c.1-.4.2-.9.2-1.4 0-.5-.1-1-.2-1.4H12V14h8.5z"/>
    </svg>
  );
}
function GitHubIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M12 .5a12 12 0 00-3.8 23.4c.6.1.8-.2.8-.5v-1.9c-3.3.7-4-1.6-4-1.6-.6-1.6-1.4-2-1.4-2-1.1-.8.1-.8.1-.8 1.3.1 2 .9 2 .9 1.1 1.9 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.6-.3-5.4-1.3-5.4-5.8 0-1.3.5-2.4 1.2-3.3-.1-.3-.5-1.6.1-3.4 0 0 1-.3 3.4 1.2a11.7 11.7 0 016.2 0C16.2 5 17.2 5.3 17.2 5.3c.6 1.8.2 3.1.1 3.4.8.9 1.2 2 1.2 3.3 0 4.5-2.8 5.5-5.4 5.8.4.3.8 1 .8 2.1v3.1c0 .3.2.6.8.5A12 12 0 0012 .5z"/>
    </svg>
  );
}
