// src/pages/Tour.jsx
import React, { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import toursData from "../data/tours.json";

/* ---------- helpers ---------- */
function mapTours(raw = []) {
  return raw.map((t, i) => {
    const id = t.id ?? t.slug ?? String(i + 1);
    return {
      id,
      title: t.title || t.name || "Untitled",
      category: (t.category || t.type || "Other").toString(),
      img: t.image || t.img || "/pics/1.jpg",
      to: `/tour/${id}`,
      summary: t.summary || t.description || "",
      tag: t.tag || "",
      slots: t.slots ?? 0,
      location: t.location || "",
      rating: Number.isFinite(t.rating) ? Number(t.rating) : 4.8,
      price: t.price ?? null, // optional
      days: t.days ?? t.duration ?? null, // optional
      difficulty: t.difficulty || t.level || "", // optional
    };
  });
}

const Badge = ({ children, className = "" }) => (
  <span className={`inline-block rounded-full bg-emerald-50 text-emerald-700 text-[11px] font-semibold px-2 py-0.5 ring-1 ring-emerald-600/20 ${className}`}>
    {children}
  </span>
);

/* ===================================================== */

export default function Tour() {
  const allTours = useMemo(() => mapTours(toursData), []);
  const categories = useMemo(() => {
    const s = new Set(allTours.map((t) => t.category || "Other"));
    return ["All", ...Array.from(s).sort((a, b) => a.localeCompare(b))];
  }, [allTours]);

  /* ---------- filters ---------- */
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("All");
  const [minRating, setMinRating] = useState(0);
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [sortKey, setSortKey] = useState("featured"); // featured | rating | az | za

  const filtered = useMemo(() => {
    let list = [...allTours];

    // text search (title / summary / location / tag)
    const term = q.trim().toLowerCase();
    if (term) {
      list = list.filter((t) =>
        [t.title, t.summary, t.location, t.tag]
          .join(" ")
          .toLowerCase()
          .includes(term)
      );
    }

    // category
    if (category !== "All") {
      list = list.filter((t) => (t.category || "Other") === category);
    }

    // rating
    if (minRating > 0) {
      list = list.filter((t) => (t.rating ?? 0) >= minRating);
    }

    // availability
    if (onlyAvailable) {
      list = list.filter((t) => (t.slots ?? 0) > 0);
    }

    // sort
    switch (sortKey) {
      case "rating":
        list.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
        break;
      case "az":
        list.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case "za":
        list.sort((a, b) => b.title.localeCompare(a.title));
        break;
      default:
        // featured: keep original order
        break;
    }

    return list;
  }, [allTours, q, category, minRating, onlyAvailable, sortKey]);

  return (
    <main className="text-slate-900">
      {/* ===== HERO ===== */}
      <section className="relative overflow-hidden bg-gradient-to-br from-emerald-600 to-emerald-700">
        <div className="absolute inset-0 opacity-[0.08]" aria-hidden>
          <HeroDots />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-16">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="text-white">
              <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-xs font-semibold ring-1 ring-white/30">
                <Pin className="w-4 h-4" /> United Kingdom
              </span>
              <h1 className="mt-3 text-4xl sm:text-5xl font-extrabold leading-tight">
                Find your next eco-adventure
              </h1>
              <p className="mt-2 text-white/90 max-w-lg">
                Hike wild ridgelines, cycle coastal paths, and join guided nature walks—picked for scenery and sustainability.
              </p>
            </div>
            <div className="hidden md:block">
              <div className="rounded-2xl overflow-hidden shadow-2xl ring-1 ring-white/20">
                <img
                  src="/pics/3.jpg"
                  alt=""
                  className="w-full h-60 md:h-72 object-cover opacity-95"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FILTER BAR ===== */}
      <section className="bg-white border-b border-emerald-900/10 sticky top-[64px] z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            {/* Search */}
            <div className="md:col-span-5">
              <label className="sr-only">Search</label>
              <div className="relative">
                <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
                  <SearchIcon className="w-5 h-5" />
                </span>
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search by name, location, or keyword…"
                  className="w-full h-11 rounded-xl border border-slate-300 bg-white pl-10 pr-3 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Category */}
            <div className="md:col-span-3">
              <label className="sr-only">Category</label>
              <div className="relative">
                <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
                  <CategoryIcon className="w-5 h-5" />
                </span>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full h-11 appearance-none rounded-xl border border-slate-300 bg-white pl-11 pr-10 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {categories.map((c) => (
                    <option key={`cat-${c}`}>{c}</option>
                  ))}
                </select>
                <span className="pointer-events-none absolute right-3 inset-y-0 my-auto text-slate-400">▾</span>
              </div>
            </div>

            {/* Min Rating */}
            <div className="md:col-span-2">
              <label className="sr-only">Min rating</label>
              <div className="relative">
                <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
                  <StarIcon className="w-5 h-5" />
                </span>
                <select
                  value={String(minRating)}
                  onChange={(e) => setMinRating(Number(e.target.value))}
                  className="w-full h-11 rounded-xl border border-slate-300 bg-white pl-11 pr-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="0">Any rating</option>
                  <option value="3">3.0+</option>
                  <option value="4">4.0+</option>
                  <option value="4.5">4.5+</option>
                </select>
              </div>
            </div>

            {/* Sort */}
            <div className="md:col-span-2">
              <label className="sr-only">Sort</label>
              <select
                value={sortKey}
                onChange={(e) => setSortKey(e.target.value)}
                className="w-full h-11 rounded-xl border border-slate-300 bg-white px-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="featured">Sort: Featured</option>
                <option value="rating">Sort: Rating</option>
                <option value="az">Sort: A → Z</option>
                <option value="za">Sort: Z → A</option>
              </select>
            </div>

            {/* Availability toggle */}
            <div className="md:col-span-12">
              <label className="inline-flex items-center gap-2 text-sm text-slate-700">
                <input
                  type="checkbox"
                  className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  checked={onlyAvailable}
                  onChange={(e) => setOnlyAvailable(e.target.checked)}
                />
                Show only tours with open slots
              </label>
              {/** Clear filters */}
              {(q || category !== "All" || minRating > 0 || onlyAvailable) && (
                <button
                  onClick={() => {
                    setQ("");
                    setCategory("All");
                    setMinRating(0);
                    setOnlyAvailable(false);
                    setSortKey("featured");
                  }}
                  className="ml-3 text-sm font-semibold text-emerald-700 hover:text-emerald-800"
                >
                  Clear filters
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ===== RESULTS ===== */}
      <section className="bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-extrabold text-emerald-700">
              {filtered.length} tour{filtered.length === 1 ? "" : "s"} found
            </h2>
            <p className="text-sm text-slate-600">
              Showing curated eco-friendly options across the UK.
            </p>
          </div>

          {filtered.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((t) => (
                <TourCard key={t.id} {...t} />
              ))}
            </div>
          )}
        </div>
      </section>
    </main>
  );
}

/* =================== UI Pieces =================== */

function TourCard({ title, img, to, summary, rating, location, tag, category, price, days, slots, difficulty }) {
  return (
    <div className="rounded-2xl overflow-hidden border border-emerald-900/10 bg-white shadow group hover:shadow-lg transition">
      <div className="relative">
        <img src={img} alt={title} className="h-48 w-full object-cover group-hover:scale-[1.02] transition" />
        {slots > 0 ? (
          <Badge className="absolute left-3 top-3 bg-emerald-600 text-white ring-white/20">Spots: {slots}</Badge>
        ) : (
          <Badge className="absolute left-3 top-3 bg-rose-600 text-white ring-white/20">Waitlist</Badge>
        )}
      </div>

      <div className="p-4">
        <div className="flex items-center gap-2 mb-1.5">
          {category && <Badge>{category}</Badge>}
          {difficulty && <Badge className="bg-emerald-50">{difficulty}</Badge>}
          {tag && <Badge className="bg-emerald-50">{tag}</Badge>}
        </div>

        <h3 className="font-bold text-slate-900 line-clamp-1">{title}</h3>
        <p className="text-sm text-slate-600 line-clamp-2 mt-0.5">{summary}</p>

        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-1">
            <span className="inline-flex items-center text-emerald-600">
              <MapPin className="w-4 h-4" />
            </span>
            <span className="text-sm text-slate-700 line-clamp-1">{location || "UK"}</span>
          </div>
          <div className="flex items-center gap-1">
            <StarDisplay value={rating} />
            <span className="text-sm text-slate-700">{rating?.toFixed ? rating.toFixed(1) : rating}</span>
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between">
          <div className="text-sm text-slate-700">
            {days ? <span>{days} day{days > 1 ? "s" : ""}</span> : <span>Flexible</span>}
            {price != null && <span className="ml-2 font-semibold text-emerald-700">£{price}</span>}
          </div>

          <Link
            to={to}
            className="inline-flex items-center gap-1 rounded-lg bg-emerald-600 text-white text-sm font-semibold px-3 py-2 hover:bg-emerald-700 transition"
          >
            View <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}

function StarDisplay({ value = 0 }) {
  const n = Math.round(value);
  return (
    <div className="flex">
      {[1, 2, 3, 4, 5].map((i) => (
        <svg key={i} viewBox="0 0 20 20" className="w-4 h-4" fill={i <= n ? "currentColor" : "none"} stroke="currentColor">
          <path d="M10 1l2.6 5.3 5.9.9-4.2 4.2 1 5.8L10 14.8 4.7 17l1-5.8L1.5 7.2l5.9-.9L10 1z" />
        </svg>
      ))}
    </div>
  );
}

function EmptyState() {
  return (
    <div className="rounded-2xl border border-dashed border-emerald-300 bg-white p-10 text-center">
      <div className="mx-auto w-12 h-12 rounded-full bg-emerald-50 grid place-items-center ring-1 ring-emerald-600/20">
        <SearchIcon className="w-6 h-6 text-emerald-600" />
      </div>
      <h3 className="mt-3 text-lg font-bold text-emerald-700">No tours match your filters</h3>
      <p className="text-sm text-slate-600 mt-1">
        Try clearing filters or searching with a different keyword.
      </p>
    </div>
  );
}

/* =================== Tiny SVGs =================== */

function SearchIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <circle cx="11" cy="11" r="7" strokeWidth="1.8" />
      <path d="M20 20l-3.5-3.5" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
function CategoryIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <rect x="3" y="3" width="8" height="8" rx="2" strokeWidth="1.8" />
      <rect x="13" y="3" width="8" height="8" rx="2" strokeWidth="1.8" />
      <rect x="3" y="13" width="8" height="8" rx="2" strokeWidth="1.8" />
      <rect x="13" y="13" width="8" height="8" rx="2" strokeWidth="1.8" />
    </svg>
  );
}
function StarIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 20 20" fill="currentColor">
      <path d="M10 1l2.6 5.3 5.9.9-4.2 4.2 1 5.8L10 14.8 4.7 17l1-5.8L1.5 7.2l5.9-.9L10 1z" />
    </svg>
  );
}
function MapPin({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M12 22s7-5.2 7-12a7 7 0 10-14 0c0 6.8 7 12 7 12z" strokeWidth="1.8" />
      <circle cx="12" cy="10" r="2.5" strokeWidth="1.8" />
    </svg>
  );
}
function Pin({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M12 22s6-4.5 6-10.5A6 6 0 006 11.5C6 17.5 12 22 12 22z" strokeWidth="1.8" />
      <circle cx="12" cy="11.5" r="2.3" strokeWidth="1.8" />
    </svg>
  );
}
function ArrowRight({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M5 12h14M13 5l7 7-7 7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function HeroDots() {
  return (
    <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <pattern id="dots-tours" width="24" height="24" patternUnits="userSpaceOnUse">
          <circle cx="1.5" cy="1.5" r="1.5" fill="white" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#dots-tours)" />
    </svg>
  );
}
