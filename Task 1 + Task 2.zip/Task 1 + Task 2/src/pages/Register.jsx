// src/pages/Register.jsx
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

/* ---------- helpers ---------- */
const validateEmail = (email = "") =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

export default function Register() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    city: "",
    activity: "Hiking",
    fitness: "Light",
    password: "",
    confirm: "",
    newsletter: true,
    terms: false,
  });

  const [showPwd, setShowPwd] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const update = (key, value) =>
    setForm((f) => ({ ...f, [key]: value }));

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (!form.name.trim()) return setError("Please enter your full name.");
    if (!validateEmail(form.email))
      return setError("Please enter a valid email.");
    if (form.password.length < 6)
      return setError("Password must be at least 6 characters.");
    if (form.password !== form.confirm)
      return setError("Passwords do not match.");
    if (!form.terms)
      return setError("You must accept the Terms & Privacy to continue.");

    try {
      setBusy(true);
      await new Promise((r) => setTimeout(r, 900));
      navigate("/");
    } catch {
      setError("Registration failed. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-[calc(100dvh-64px)] flex items-center justify-center bg-gradient-to-b from-emerald-50 to-emerald-100 px-4 py-8">
      <div className="w-full max-w-3xl lg:max-w-5xl">
        {/* Card: inside becomes scrollable when tall */}
        <div className="grid grid-cols-1 lg:grid-cols-2 overflow-hidden rounded-3xl shadow-2xl border border-emerald-900/10 bg-white/95 backdrop-blur">
          {/* Left: Brand + Form (scroll container) */}
          <section className="p-6 sm:p-10 max-h-[calc(100dvh-120px)] overflow-y-auto overscroll-contain scroll-smooth">
            {/* Brand */}
            <div className="flex items-center justify-center gap-3 mb-6">
              <img
                src="/pics/logo.jpeg"
                alt="EcoVenture Logo"
                className="w-10 h-10 rounded-full ring-2 ring-emerald-500/40 object-contain"
              />
              <h1 className="text-2xl font-extrabold bg-gradient-to-r from-emerald-600 to-emerald-700 bg-clip-text text-transparent">
                EcoVenture
              </h1>
            </div>

            <h2 className="text-center text-3xl font-extrabold text-emerald-700">
              Create your account
            </h2>
            <p className="text-center text-sm text-slate-600 mt-2">
              Join eco-friendly hiking, cycling, and nature walk adventures across the UK.
            </p>

            {error ? (
              <div
                role="alert"
                className="mt-6 rounded-xl border border-red-300/70 bg-red-50 text-red-700 px-4 py-3 text-sm text-center"
              >
                {error}
              </div>
            ) : (
              <div className="mt-6" />
            )}

            <form
              onSubmit={handleSubmit}
              className="grid grid-cols-1 sm:grid-cols-2 gap-5 sm:gap-6"
            >
              {/* Full name */}
              <Field
                id="name"
                label="Full name"
                placeholder="Jane Doe"
                value={form.name}
                onChange={(v) => update("name", v)}
                icon={<UserIcon className="w-5 h-5" />}
                className="sm:col-span-2"
              />

              {/* Email */}
              <Field
                id="email"
                type="email"
                label="Email"
                placeholder="you@example.com"
                value={form.email}
                onChange={(v) => update("email", v)}
                icon={<MailIcon className="w-5 h-5" />}
                className="sm:col-span-2"
                autoComplete="email"
              />

              {/* Phone */}
              <Field
                id="phone"
                label="Phone (optional)"
                placeholder="+44 7123 456789"
                value={form.phone}
                onChange={(v) => update("phone", v)}
                icon={<PhoneIcon className="w-5 h-5" />}
              />

              {/* City */}
              <Field
                id="city"
                label="Home city"
                placeholder="Manchester"
                value={form.city}
                onChange={(v) => update("city", v)}
                icon={<LocationIcon className="w-5 h-5" />}
              />

              {/* Preferred activity */}
              <SelectWithIcon
                id="activity"
                label="Preferred activity"
                value={form.activity}
                onChange={(v) => update("activity", v)}
                icon={<ActivityIcon className="w-5 h-5" />}
                options={["Hiking", "Cycling", "Nature Walks"]}
              />

              {/* Fitness level */}
              <SelectPlain
                id="fitness"
                label="Fitness level"
                value={form.fitness}
                onChange={(v) => update("fitness", v)}
                options={["Light", "Moderate", "Intense"]}
              />

              {/* Password */}
              <PasswordField
                id="password"
                label="Password"
                placeholder="Create a password"
                value={form.password}
                onChange={(v) => update("password", v)}
                show={showPwd}
                setShow={setShowPwd}
                className="sm:col-span-2"
              />

              {/* Confirm password */}
              <PasswordField
                id="confirm"
                label="Confirm password"
                placeholder="Re-enter password"
                value={form.confirm}
                onChange={(v) => update("confirm", v)}
                show={showConfirm}
                setShow={setShowConfirm}
                className="sm:col-span-2"
              />

              {/* Options */}
              <div className="sm:col-span-2 flex flex-col gap-4 mt-1">
                <label className="inline-flex items-start gap-3 text-sm text-slate-700">
                  <input
                    type="checkbox"
                    className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                    checked={form.newsletter}
                    onChange={(e) => update("newsletter", e.target.checked)}
                  />
                  <span>Subscribe to tour updates &amp; offers</span>
                </label>

                <label className="inline-flex items-start gap-3 text-sm text-slate-700">
                  <input
                    type="checkbox"
                    className="mt-0.5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                    checked={form.terms}
                    onChange={(e) => update("terms", e.target.checked)}
                  />
                  <span className="leading-5">
                    I agree to the{" "}
                    <Link
                      to="/terms"
                      className="font-semibold text-emerald-600 hover:text-emerald-700"
                    >
                      Terms
                    </Link>{" "}
                    &amp;{" "}
                    <Link
                      to="/privacy"
                      className="font-semibold text-emerald-600 hover:text-emerald-700"
                    >
                      Privacy
                    </Link>
                    .
                  </span>
                </label>
              </div>

              {/* Submit */}
              <div className="sm:col-span-2 mt-1">
                <button
                  type="submit"
                  disabled={busy}
                  className="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-70 text-white font-semibold transition transform active:scale-[0.99] shadow-lg shadow-emerald-600/20"
                >
                  <span className="inline-flex items-center justify-center gap-2">
                    {busy && <Spinner className="w-4 h-4" />}
                    {busy ? "Creating account…" : "Create account"}
                  </span>
                </button>
              </div>

              {/* Already have account */}
              <div className="sm:col-span-2 text-center text-sm text-slate-600 pb-1">
                Already have an account?{" "}
                <Link
                  to="/login"
                  className="font-semibold text-emerald-600 hover:text-emerald-700"
                >
                  Sign in
                </Link>
              </div>
            </form>
          </section>

          {/* Right: Accent panel (lg+) */}
          <aside className="relative hidden lg:block bg-gradient-to-br from-emerald-600 via-emerald-700 to-emerald-800">
            <div className="absolute inset-0 opacity-[0.08]" aria-hidden>
              <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="dots-reg" width="24" height="24" patternUnits="userSpaceOnUse">
                    <circle cx="1.5" cy="1.5" r="1.5" fill="white" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#dots-reg)" />
              </svg>
            </div>
            <div className="relative h-full p-10 text-white flex flex-col items-center justify-center text-center">
              <h3 className="text-2xl font-extrabold">Start your eco-journey</h3>
              <p className="mt-2 text-sm text-white/90 max-w-xs">
                Build your profile so we can match you with the best sustainable tours.
              </p>
            </div>
          </aside>
        </div>
      </div>
    </main>
  );
}

/* ---------- Small building blocks (JSX) ---------- */
function Label(props) {
  return (
    <label
      {...props}
      className={[
        "block text-sm font-medium text-slate-700 mb-1",
        props.className || "",
      ].join(" ")}
    />
  );
}

function Field({
  id,
  label,
  placeholder,
  value,
  onChange,
  icon,
  className,
  type = "text",
  autoComplete,
}) {
  return (
    <div className={className}>
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        {icon && (
          <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
            {icon}
          </span>
        )}
        <input
          id={id}
          type={type}
          value={value}
          autoComplete={autoComplete}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={[
            "w-full h-12 rounded-xl border border-slate-300 bg-white",
            icon ? "pl-11 pr-3" : "px-3",
            "text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500",
          ].join(" ")}
        />
      </div>
    </div>
  );
}

function SelectWithIcon({ id, label, value, onChange, options, icon }) {
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
          {icon}
        </span>
        <select
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full h-12 appearance-none rounded-xl border border-slate-300 bg-white pl-11 pr-10 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        >
          {options.map((o) => (
            <option key={`${id}-${o}`}>{o}</option>
          ))}
        </select>
        <span className="pointer-events-none absolute right-3 inset-y-0 my-auto text-slate-400">
          ▾
        </span>
      </div>
    </div>
  );
}

function SelectPlain({ id, label, value, onChange, options }) {
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-12 rounded-xl border border-slate-300 bg-white px-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
      >
        {options.map((o) => (
          <option key={`${id}-${o}`}>{o}</option>
        ))}
      </select>
    </div>
  );
}

function PasswordField({
  id,
  label,
  placeholder,
  value,
  onChange,
  show,
  setShow,
  className,
}) {
  return (
    <div className={className}>
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <span className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-slate-400">
          <LockIcon className="w-5 h-5" />
        </span>
        <input
          id={id}
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full h-12 rounded-xl border border-slate-300 bg-white pl-11 pr-12 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          aria-label={show ? "Hide password" : "Show password"}
          className="absolute inset-y-0 right-2 my-auto h-8 px-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-emerald-600 flex items-center"
        >
          {show ? "Hide" : "Show"}
        </button>
      </div>
    </div>
  );
}

/* ---------- Inline SVG Icons ---------- */
function MailIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden>
      <rect x="3" y="5" width="18" height="14" rx="2" strokeWidth="1.8" />
      <path d="M3 7l9 6 9-6" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function LockIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden>
      <rect x="5" y="10" width="14" height="10" rx="2" strokeWidth="1.8" />
      <path d="M8 10V7a4 4 0 118 0v3" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
function UserIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden>
      <circle cx="12" cy="8" r="4" strokeWidth="1.8" />
      <path d="M4 20c2-3.5 6-5 8-5s6 1.5 8 5" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
function PhoneIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden>
      <path d="M6.6 10.8a15 15 0 006.6 6.6l2.2-2.2a1.5 1.5 0 011.6-.36c1.1.4 2.3.6 3.5.6a1.5 1.5 0 011.5 1.5V21a1.5 1.5 0 01-1.5 1.5C9.4 22.5 1.5 14.6 1.5 4.5A1.5 1.5 0 013 3h2.1A1.5 1.5 0 016.6 4.5c0 1.2.2 2.4.6 3.5.2.5.1 1.1-.36 1.6l-2.24 2.2z" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
function LocationIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden>
      <path d="M12 22s7-5.2 7-12a7 7 0 10-14 0c0 6.8 7 12 7 12z" strokeWidth="1.8" />
      <circle cx="12" cy="10" r="2.5" strokeWidth="1.8" />
    </svg>
  );
}
function ActivityIcon({ className = "" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden>
      <path d="M3 12h4l3 7 4-14 3 7h4" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function Spinner({ className = "" }) {
  return (
    <svg className={`animate-spin ${className}`} viewBox="0 0 24 24" aria-hidden>
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
      <path className="opacity-90" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
    </svg>
  );
}
